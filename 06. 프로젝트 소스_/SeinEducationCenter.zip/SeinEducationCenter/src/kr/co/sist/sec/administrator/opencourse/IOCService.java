package kr.co.sist.sec.administrator.opencourse;

public interface IOCService {

	void list();

	void listByCondition();

	void add();

	void edit();

	void del();

	void subjectList();

	void studentList();

}
