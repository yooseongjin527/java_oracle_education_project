package kr.co.sist.sec.dto;

public class DTOAttendance {
	
	private String Attendance;
	private String geuntae_seq;
	private String status_seq;
	
	public String getAttendance() {
		return Attendance;
	}
	
	public void setAttendance(String attendance) {
		Attendance = attendance;
	}
	
	public String getGeuntae_seq() {
		return geuntae_seq;
	}
	
	public void setGeuntae_seq(String geuntae_seq) {
		this.geuntae_seq = geuntae_seq;
	}
	
	public String getStatus_seq() {
		return status_seq;
	}
	
	public void setStatus_seq(String status_seq) {
		this.status_seq = status_seq;
	}
	
	
	
	
	

}
