package kr.co.sist.sec.administrator.student;

public interface IServiceAdministorStudent {

	void add();

	void list();

	void edit();

	void del();

	void nameSearch();
	
	void selectedStudentInfo();

}
