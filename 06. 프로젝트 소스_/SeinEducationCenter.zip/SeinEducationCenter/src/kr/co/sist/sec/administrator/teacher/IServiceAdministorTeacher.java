package kr.co.sist.sec.administrator.teacher;

public interface IServiceAdministorTeacher {

	void add();

	void list();

	void edit();

	void del();

	void nameSearch();
	
	void selectedTeacherInfo();
	
}
