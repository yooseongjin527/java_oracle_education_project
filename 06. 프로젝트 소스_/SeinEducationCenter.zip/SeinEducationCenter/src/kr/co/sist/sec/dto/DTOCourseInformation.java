package kr.co.sist.sec.dto;

public class DTOCourseInformation {
	
	private String seq;
	private String course_name;
	private String course_period;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	public String getCourse_period() {
		return course_period;
	}
	public void setCourse_period(String course_period) {
		this.course_period = course_period;
	}
	
	
}
