package kr.co.sist.sec.dto;

public class DTOAllot {
	private String seq;
	private String attendance_allot;
	private String writtentest_allot;
	private String performancetest_allot;
	private String opensubject_seq;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getAttendance_allot() {
		return attendance_allot;
	}
	public void setAttendance_allot(String attendance_allot) {
		this.attendance_allot = attendance_allot;
	}
	public String getWrittentest_allot() {
		return writtentest_allot;
	}
	public void setWrittentest_allot(String writtentest_allot) {
		this.writtentest_allot = writtentest_allot;
	}
	public String getPerformancetest_allot() {
		return performancetest_allot;
	}
	public void setPerformancetest_allot(String performancetest_allot) {
		this.performancetest_allot = performancetest_allot;
	}
	public String getOpensubject_seq() {
		return opensubject_seq;
	}
	public void setOpensubject_seq(String opensubject_seq) {
		this.opensubject_seq = opensubject_seq;
	}
	
	
}
