package kr.co.sist.sec.dto;

public class DTOCourseSubjectTextbook {
	private String csseq;
	private String cscourse_seq;
	private String subject_seq;
	private String sseq;
	private String sname;
	private String sstatus;
	private String tbseq;
	private String tbname;
	private String tbpublisher;
	private String tbauthor;
	private String tbstatus;
	
	public String getCsseq() {
		return csseq;
	}
	public void setCsseq(String csseq) {
		this.csseq = csseq;
	}
	public String getCscourse_seq() {
		return cscourse_seq;
	}
	public void setCscourse_seq(String cscourse_seq) {
		this.cscourse_seq = cscourse_seq;
	}
	public String getSubject_seq() {
		return subject_seq;
	}
	public void setSubject_seq(String subject_seq) {
		this.subject_seq = subject_seq;
	}
	public String getSseq() {
		return sseq;
	}
	public void setSseq(String sseq) {
		this.sseq = sseq;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSstatus() {
		return sstatus;
	}
	public void setSstatus(String sstatus) {
		this.sstatus = sstatus;
	}
	public String getTbseq() {
		return tbseq;
	}
	public void setTbseq(String tbseq) {
		this.tbseq = tbseq;
	}
	public String getTbname() {
		return tbname;
	}
	public void setTbname(String tbname) {
		this.tbname = tbname;
	}
	public String getTbpublisher() {
		return tbpublisher;
	}
	public void setTbpublisher(String tbpublisher) {
		this.tbpublisher = tbpublisher;
	}
	public String getTbauthor() {
		return tbauthor;
	}
	public void setTbauthor(String tbauthor) {
		this.tbauthor = tbauthor;
	}
	public String getTbstatus() {
		return tbstatus;
	}
	public void setTbstatus(String tbstatus) {
		this.tbstatus = tbstatus;
	}
	
	
	
}
