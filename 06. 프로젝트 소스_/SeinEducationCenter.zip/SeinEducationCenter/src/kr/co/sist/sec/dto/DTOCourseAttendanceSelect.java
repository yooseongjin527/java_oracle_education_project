package kr.co.sist.sec.dto;

public class DTOCourseAttendanceSelect {
	
	private String opencourse_seq;
	private String opencourse_name;

	public String getOpencourse_name() {
		return opencourse_name;
	}

	public void setOpencourse_name(String opencourse_name) {
		this.opencourse_name = opencourse_name;
	}

	public String getOpencourse_seq() {
		return opencourse_seq;
	}

	public void setOpencourse_seq(String opencourse_seq) {
		this.opencourse_seq = opencourse_seq;
	}
	
	
	
}
