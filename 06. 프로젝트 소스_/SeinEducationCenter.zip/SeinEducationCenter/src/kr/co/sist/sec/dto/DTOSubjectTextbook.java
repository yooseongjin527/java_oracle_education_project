package kr.co.sist.sec.dto;

public class DTOSubjectTextbook {
	private String sseq;
	private String sname;
	private String sstatus;
	private String tseq;
	private String tname;
	private String tpublisher;
	private String tauthor;
	private String tstatus;
	
	public String getSseq() {
		return sseq;
	}
	public void setSseq(String sseq) {
		this.sseq = sseq;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSstatus() {
		return sstatus;
	}
	public void setSstatus(String sstatus) {
		this.sstatus = sstatus;
	}
	public String getTseq() {
		return tseq;
	}
	public void setTseq(String tseq) {
		this.tseq = tseq;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTpublisher() {
		return tpublisher;
	}
	public void setTpublisher(String tpublisher) {
		this.tpublisher = tpublisher;
	}
	public String getTauthor() {
		return tauthor;
	}
	public void setTauthor(String tauthor) {
		this.tauthor = tauthor;
	}
	public String getTstatus() {
		return tstatus;
	}
	public void setTstatus(String tstatus) {
		this.tstatus = tstatus;
	}
	
	
}
