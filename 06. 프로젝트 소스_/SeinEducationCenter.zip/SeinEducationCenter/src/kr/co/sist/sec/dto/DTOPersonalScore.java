package kr.co.sist.sec.dto;

public class DTOPersonalScore {
	
	private String student_name;
	private String ssn;
	private String opencourse_name;
	private String opencourse_period;
	private String teacher_name;
	private String classroom_name;
	
	
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public String getOpencourse_name() {
		return opencourse_name;
	}
	public void setOpencourse_name(String opencourse_name) {
		this.opencourse_name = opencourse_name;
	}
	public String getOpencourse_period() {
		return opencourse_period;
	}
	public void setOpencourse_period(String opencourse_period) {
		this.opencourse_period = opencourse_period;
	}
	public String getTeacher_name() {
		return teacher_name;
	}
	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}
	public String getClassroom_name() {
		return classroom_name;
	}
	public void setClassroom_name(String classroom_name) {
		this.classroom_name = classroom_name;
	}
	
	
	
	
}
