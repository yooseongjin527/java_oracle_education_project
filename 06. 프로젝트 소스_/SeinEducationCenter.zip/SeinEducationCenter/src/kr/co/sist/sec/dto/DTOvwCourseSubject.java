package kr.co.sist.sec.dto;

public class DTOvwCourseSubject {
	private String csseq;
	private String course_seq;
	private String subject_seq;
	private String stext_seq;
	private String sname;
	private String sstatus;
	
	public String getCsseq() {
		return csseq;
	}
	public void setCsseq(String csseq) {
		this.csseq = csseq;
	}
	public String getCourse_seq() {
		return course_seq;
	}
	public void setCourse_seq(String course_seq) {
		this.course_seq = course_seq;
	}
	public String getSubject_seq() {
		return subject_seq;
	}
	public void setSubject_seq(String subject_seq) {
		this.subject_seq = subject_seq;
	}
	public String getStext_seq() {
		return stext_seq;
	}
	public void setStext_seq(String stext_seq) {
		this.stext_seq = stext_seq;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSstatus() {
		return sstatus;
	}
	public void setSstatus(String sstatus) {
		this.sstatus = sstatus;
	}
	
	
	
}
