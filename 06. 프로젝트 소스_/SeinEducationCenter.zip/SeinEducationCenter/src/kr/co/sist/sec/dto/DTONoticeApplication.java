package kr.co.sist.sec.dto;

public class DTONoticeApplication {
	
	private String seq;
	private String notice_seq;
	private String application_date;
	private String opencoursestudent_seq;
	
	public String getSeq() {
		return seq;
	}
	
	public void setSeq(String seq) {
		this.seq = seq;
	}
	
	public String getNotice_seq() {
		return notice_seq;
	}
	
	public void setNotice_seq(String notice_seq) {
		this.notice_seq = notice_seq;
	}
	
	public String getApplication_date() {
		return application_date;
	}
	
	public void setApplication_date(String application_date) {
		this.application_date = application_date;
	}
	
	public String getOpencoursestudent_seq() {
		return opencoursestudent_seq;
	}
	
	public void setOpencoursestudent_seq(String opencoursestudent_seq) {
		this.opencoursestudent_seq = opencoursestudent_seq;
	}
	

	
	
}

