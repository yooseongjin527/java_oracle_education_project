package kr.co.sist.sec.administrator.coursesubject;

public interface ICSService {
	void list();

	void add();

	void del();

}
