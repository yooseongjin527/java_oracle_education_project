package kr.co.sist.sec.dto;

public class DTOvwOCOSCSS {
	private String ocseq;
	private String cseq;
	private String ocstart_date;
	private String ocend_date;
	private String occlassroom_seq;
	private String octeacher_seq;
	private String ocstatus;
	private String osseq;
	private String csseq;
	private String osstart_date;
	private String osend_date;
	private String cssubject_seq;
	private String stext_seq;
	private String sname;
	private String sstatus;
	public String getOcseq() {
		return ocseq;
	}
	public void setOcseq(String ocseq) {
		this.ocseq = ocseq;
	}
	public String getCseq() {
		return cseq;
	}
	public void setCseq(String cseq) {
		this.cseq = cseq;
	}
	public String getOcstart_date() {
		return ocstart_date;
	}
	public void setOcstart_date(String ocstart_date) {
		this.ocstart_date = ocstart_date;
	}
	public String getOcend_date() {
		return ocend_date;
	}
	public void setOcend_date(String ocend_date) {
		this.ocend_date = ocend_date;
	}
	public String getOcclassroom_seq() {
		return occlassroom_seq;
	}
	public void setOcclassroom_seq(String occlassroom_seq) {
		this.occlassroom_seq = occlassroom_seq;
	}
	public String getOcteacher_seq() {
		return octeacher_seq;
	}
	public void setOcteacher_seq(String octeacher_seq) {
		this.octeacher_seq = octeacher_seq;
	}
	public String getOcstatus() {
		return ocstatus;
	}
	public void setOcstatus(String ocstatus) {
		this.ocstatus = ocstatus;
	}
	public String getOsseq() {
		return osseq;
	}
	public void setOsseq(String osseq) {
		this.osseq = osseq;
	}
	public String getCsseq() {
		return csseq;
	}
	public void setCsseq(String csseq) {
		this.csseq = csseq;
	}
	public String getOsstart_date() {
		return osstart_date;
	}
	public void setOsstart_date(String osstart_date) {
		this.osstart_date = osstart_date;
	}
	public String getOsend_date() {
		return osend_date;
	}
	public void setOsend_date(String osend_date) {
		this.osend_date = osend_date;
	}
	public String getCssubject_seq() {
		return cssubject_seq;
	}
	public void setCssubject_seq(String cssubject_seq) {
		this.cssubject_seq = cssubject_seq;
	}
	public String getStext_seq() {
		return stext_seq;
	}
	public void setStext_seq(String stext_seq) {
		this.stext_seq = stext_seq;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSstatus() {
		return sstatus;
	}
	public void setSstatus(String sstatus) {
		this.sstatus = sstatus;
	}
	
	
	
}
