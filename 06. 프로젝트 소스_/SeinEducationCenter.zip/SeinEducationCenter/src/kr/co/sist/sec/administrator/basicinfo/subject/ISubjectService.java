package kr.co.sist.sec.administrator.basicinfo.subject;

public interface ISubjectService {

	void list();

	void search();

	void add();

	void edit();

	void del();
	
}
