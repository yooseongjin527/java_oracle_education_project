package kr.co.sist.sec.dto;

public class DTOvwOCCSS {
	private String ocseq;
	private String cseq;
	private String ocstart_date;
	private String ocend_date;
	private String occlassroom_seq;
	private String octeacher_seq;
	private String ocstatus;
	private String sseq;
	private String stext_seq;
	private String sname;
	private String sstatus;
	
	public String getOcseq() {
		return ocseq;
	}
	public void setOcseq(String ocseq) {
		this.ocseq = ocseq;
	}
	public String getCseq() {
		return cseq;
	}
	public void setCseq(String cseq) {
		this.cseq = cseq;
	}
	public String getOcstart_date() {
		return ocstart_date;
	}
	public void setOcstart_date(String ocstart_date) {
		this.ocstart_date = ocstart_date;
	}
	public String getOcend_date() {
		return ocend_date;
	}
	public void setOcend_date(String ocend_date) {
		this.ocend_date = ocend_date;
	}
	public String getOcclassroom_seq() {
		return occlassroom_seq;
	}
	public void setOcclassroom_seq(String occlassroom_seq) {
		this.occlassroom_seq = occlassroom_seq;
	}
	public String getOcteacher_seq() {
		return octeacher_seq;
	}
	public void setOcteacher_seq(String octeacher_seq) {
		this.octeacher_seq = octeacher_seq;
	}
	public String getOcstatus() {
		return ocstatus;
	}
	public void setOcstatus(String ocstatus) {
		this.ocstatus = ocstatus;
	}
	public String getSseq() {
		return sseq;
	}
	public void setSseq(String sseq) {
		this.sseq = sseq;
	}
	public String getStext_seq() {
		return stext_seq;
	}
	public void setStext_seq(String stext_seq) {
		this.stext_seq = stext_seq;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSstatus() {
		return sstatus;
	}
	public void setSstatus(String sstatus) {
		this.sstatus = sstatus;
	}
	
	
}
