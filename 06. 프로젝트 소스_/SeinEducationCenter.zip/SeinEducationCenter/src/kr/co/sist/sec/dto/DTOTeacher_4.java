package kr.co.sist.sec.dto;

public class DTOTeacher_4 {

	private String OpenSubject_seq;
	private String Student_name;
	private String Student_tel;
	private String Student_regdate;
	private String OpenCourseStudent_status;

	public String getOpenSubject_seq() {
		return OpenSubject_seq;
	}

	public void setOpenSubject_seq(String openSubject_seq) {
		OpenSubject_seq = openSubject_seq;
	}

	public String getStudent_name() {
		return Student_name;
	}

	public void setStudent_name(String student_name) {
		Student_name = student_name;
	}

	public String getStudent_tel() {
		return Student_tel;
	}

	public void setStudent_tel(String student_tel) {
		Student_tel = student_tel;
	}

	public String getStudent_regdate() {
		return Student_regdate;
	}

	public void setStudent_regdate(String student_regdate) {
		Student_regdate = student_regdate;
	}

	public String getOpenCourseStudent_status() {
		return OpenCourseStudent_status;
	}

	public void setOpenCourseStudent_status(String openCourseStudent_status) {
		OpenCourseStudent_status = openCourseStudent_status;
	}

}
