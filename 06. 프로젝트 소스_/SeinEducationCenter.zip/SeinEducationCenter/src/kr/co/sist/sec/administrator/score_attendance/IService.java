package kr.co.sist.sec.administrator.score_attendance;

public interface IService {
	
	void testmanage();
	
	void subjectselect();
	
	void personalscodetail();
	
	void periattendance();
	
	void courseattendancesel();
	
	void personalattendance();
	
	void company();
	
	void teachertest();
	
}
