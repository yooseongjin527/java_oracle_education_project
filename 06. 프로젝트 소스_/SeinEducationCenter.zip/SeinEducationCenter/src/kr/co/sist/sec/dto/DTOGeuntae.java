package kr.co.sist.sec.dto;

public class DTOGeuntae {
	
	private String seq;
	private String opencoursestudent_seq;
	private String geuntae_date;
	private String check_in;
	private String check_out;
	
	public String getSeq() {
		return seq;
	}
	
	public void setSeq(String seq) {
		this.seq = seq;
	}
	
	public String getOpencoursestudent_seq() {
		return opencoursestudent_seq;
	}
	
	public void setOpencoursestudent_seq(String opencoursestudent_seq) {
		this.opencoursestudent_seq = opencoursestudent_seq;
	}
	
	public String getGeuntae_date() {
		return geuntae_date;
	}
	
	public void setGeuntae_date(String geuntae_date) {
		this.geuntae_date = geuntae_date;
	}
	
	public String getCheck_in() {
		return check_in;
	}
	
	public void setCheck_in(String check_in) {
		this.check_in = check_in;
	}
	
	public String getCheck_out() {
		return check_out;
	}
	
	public void setCheck_out(String check_out) {
		this.check_out = check_out;
	}
	
	
	
	

}
