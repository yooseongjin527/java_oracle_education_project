package kr.co.sist.sec.administrator.basicinfo.course;

public interface ICourseService {
	
	void search();

	void list();

	void add();

	void edit();

	void del();

}
